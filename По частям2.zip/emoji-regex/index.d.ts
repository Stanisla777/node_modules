declare module 'emoji-regex' {
    function emojiRegex(): RegExp;

    export default emojiRegex;
}

declare module 'emoji-regex/text' {
    function emojiRegex(): RegExp;

    export default emojiRegex;
}

declare module 'emoji-regex/es2015' {
    function emojiRegex(): RegExp;

    export default emojiRegex;
}

declare module 'emoji-regex/es2015/text' {
    function emojiRegex(): RegExp;

    export default emojiRegex;
}
