# `sass-embedded-win32-x64`

This is the **win32-x64** binary for [`sass-embedded`](https://www.npmjs.com/package/sass-embedded)
