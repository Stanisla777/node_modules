<template lang="pug">
  div#earlyRepayment
    .calc-tax-deduc-new__block.mor-rep-calculators__block.mobile-padding.calc-tax-deduc-new__area.margin.grey.js--container-block.js--container-block-early.js-accordion-parent-calc(
      v-for="(item,index) in array_block_early_repayment" :key="item.id"
      ref="erlyRepayment"
      :data-index="item.id"

    )
      .calc-tax-deduc-new__container-title
        .calc-tax-deduc-new__row-title-container.not-margin
          h3.calc-tax-deduc-new__block-title.mor-rep-calculators__block-title.big(@click="dropdownArea") Досрочное погашение
          .mor-rep-calculators__alarm.display-none.js--wrapper-match-alarm
          .mor-rep-calculators__folding-block
            .mor-rep-calculators__folding-block-icon

      .calc-tax-deduc-new__wr-function-block.padding.active
        .calc-tax-deduc-new__acc-wr.js--acc-wr
          .calc-tax-deduc-new__block-subtitle
            p Заполните, если вносили или планируете внести платеж по досрочному погашению кредита.
            p Ежемесячный платеж не входит в сумму досрочного погашения.

          .mor-rep-calculators__body-block.mor-rep-calculators__body-block-eerly-repayment.js--container-repeat-mor

            .calc-tax-deduc-new__row.mobile-margin.js--tax-deduc-row
              .calc-tax-deduc-new__row-three-column
                component-calendar(
                  :ref="`js-calendar-early-repayment-${item.id}`"
                  :class_calendar="`js-calendar-early-repayment-${item.id}`"
                  :blockId="item.id"
                  :min_date_holidays="min_date_holidays"
                  :array_block_early_repayment_main="array_block_early_repayment_main"
                  :max_date="max_date"
                  :loan_term="loan_term"
                  :array_selected_dates="array_selected_dates"
                  :tooltip_early="tooltip_early"
                  :answers="answers"
                  :time_data_loan="time_data_loan"


                  @sendEearlyRepayment="receivedEearlyRepayment"
                  @sendClearHolidayReceive="receivedClearHolidayReceive"
                  @sendEearlyRepaymentClearAll="receivedEearlyRepaymentClear"

                )

                .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--calc-row-input.js--container-block-required.js--tooltip-parent
                  .calc-tax-deduc-new__row-title-container
                    p.calc-tax-deduc-new__row-title Сумма, ₽
                    span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_early['early-amount']!==''")
                      span.content-note__text {{tooltip_early["early-amount"]}}
                    span.content-note.mobile(
                      v-if="tooltip_early['early-amount']!==''"
                      @click="openTooltipMobile"
                    )
                  div(v-if="tooltip_early['early-amount']!==''")
                    .select__background.modal-special-background(@click="closeTooltipMobile")
                    .select-list__selection-window.modal-special-styles.js--openlist-body
                      .select-list__head
                        p Сумма
                        .select-list__head-close(@click="closeTooltipMobile")
                          svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                      .select-list__wr-search.mor-rep-calculators__wr-search
                        p {{tooltip_early["early-amount"]}}


                  .calc-tax-deduc-new__col-input.js--number-debt.js--tex-deduc-input.js--for-clear-field
                    input.js--normal-field.js-early-required.js-early-required-for-button(
                      inputmode="numeric"
                      placeholder="Введите сумму"
                      @keyup="fieldNotEmpty"
                      @focus="inpFocus"
                      @blur="inpBlur"
                      @input="multiplyActionsInpuLoanAmount(1000000000,$event)"
                    )
                    .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                      @click="clearInputEarlyRepayment"
                    )
                  p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения


                .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--container-block-required.js--tooltip-parent
                  .calc-tax-deduc-new__row-title-container
                    p.calc-tax-deduc-new__row-title Периодичность
                    span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_early['early-frequency']!==''")
                      span.content-note__text {{tooltip_early["early-frequency"]}}
                    span.content-note.mobile(
                      v-if="tooltip_early['early-frequency']!==''"
                      @click="openTooltipMobile"
                    )
                  div(v-if="tooltip_early['early-frequency']!==''")
                    .select__background.modal-special-background(@click="closeTooltipMobile")
                    .select-list__selection-window.modal-special-styles.js--openlist-body
                      .select-list__head
                        p Периодичность
                        .select-list__head-close(@click="closeTooltipMobile")
                          svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                      .select-list__wr-search.mor-rep-calculators__wr-search
                        p {{tooltip_early["early-frequency"]}}

                  .select-list__wrapper.js--select.js--openlist-container.js--only-mobile-fixed.js--for-clear-field.js--for-clear-list-periodicity
                    .select__background.modal-special-background.mor-rep-calculators__background-periodicity.js--openlist-background
                    .select__choosen.select__choosen-whith-clear.select__choosen_bordered.js--openlist-btn
                      p.select__substituted-text.input-emty.js--select-option.js-early-required.js-early-required-for-button Выберите параметр
                      .select__wrap-technical-elements
                        .calc-tax-deduc-new__input-clear.js--clear-calc-tax(
                          @click="clearPeriodicity"
                        )
                        .select__arrow-search
                          svg(width='12', height='8', viewbox='0 0 12 8', fill='none', xmlns='http://www.w3.org/2000/svg')
                            path(fill-rule='evenodd', clip-rule='evenodd', d='M11.753 0.868692C11.9987 1.13419 12.0361 1.58803 11.7904 1.85353L6.50907 7.10074C6.22563 7.40708 5.76607 7.40707 5.48263 7.10074L0.210749 1.84152C-0.0349036 1.57603 -0.000290891 1.13927 0.245361 0.873779C0.491014 0.608285 0.974545 0.608131 1.2202 0.873625L6.00253 5.59224L10.7671 0.868661C11.0127 0.603166 11.5074 0.603198 11.753 0.868692Z', fill='#252628')
                    .select-list__selection-window.modal-special-styles.mor-rep-calculators__list-periodicity.js--openlist-body
                      .select-list__head
                        p Периодичность
                        .select-list__head-close.js--select-list-close
                          svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                      .select-list__wr-search
                        .select-list__search-item.js--openlist-item(
                          v-for="item in array_periodicity"
                          :data-key="item.key"
                          @click="selectPeriod"

                        )
                          p {{item.title}}
                  p.mor-rep-calculators__input-error.js--required-error.display-none Это поле обязательное для заполнения


            //Период повторения
            .calc-tax-deduc-new__row.mor-rep-calculators__repetition-period.mor-rep-calculators__parent-tooltip-mobile.js--tax-deduc-row.js--repetition-period.js--tooltip-parent
              .calc-tax-deduc-new__row-title-container
                p.calc-tax-deduc-new__row-title Период повторения
                span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_early['early-repetition-period']!==''")
                  span.content-note__text {{tooltip_early["early-repetition-period"]}}
                span.content-note.mobile(
                  v-if="tooltip_early['early-repetition-period']!==''"
                  @click="openTooltipMobile"
                )
              div(v-if="tooltip_early['early-repetition-period']!==''")
                .select__background.modal-special-background(@click="closeTooltipMobile")
                .select-list__selection-window.modal-special-styles.js--openlist-body
                  .select-list__head
                    p Период повторения
                    .select-list__head-close(@click="closeTooltipMobile")
                      svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                        path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                  .select-list__wr-search.mor-rep-calculators__wr-search
                    p {{tooltip_early["early-repetition-period"]}}
              .mor-rep-calculators__container-radio-type
                .checkbox-stylized.feed_back__user-form-subscription.js--checkbox_wrapper
                  .personal-office__user-form-subscription-em

                  .feed_back__user-form-block
                      input(
                        :id="`all-term-${item.id}-0`"
                        type="radio"
                        value="all-term"
                        :name="`period-term-${item.id}`"
                        checked="checked"
                        @change="selectRepetitionPeriod"
                      )
                      label.feed_back__radio-label(:for="`all-term-${item.id}-0`")
                          p На весь срок кредита

                .checkbox-stylized.feed_back__user-form-subscription.js--checkbox_wrapper
                  .personal-office__user-form-subscription-em
                  .feed_back__user-form-block
                      input#choose-term(
                        :id="`all-term-${item.id}-1`"
                        type="radio"
                        value="choose-term"
                        :name="`period-term-${item.id}`"
                        @change="selectRepetitionPeriod"
                      )
                      label.feed_back__radio-label(:for="`all-term-${item.id}-1`")
                          p Выбрать период

            //календарь периодов при выборе радиокнопки Выбрать период
            .mor-rep-calculators__wrapper-calendar-repetition-period.calc-tax-deduc-new__row-input.not-show.js--period-calendar
                template
                  component-calendar-period-begin(
                    :ref="`js-calendar-early-period-begin-${item.id}`"
                    :class_calendar="`js-calendar-early-period-begin-${item.id}`"
                    :blockId="item.id"
                    :min_date_holidays_begin="min_date_holidays_begin"
                    :array_block_early_repayment_period="array_block_early_repayment_period"
                    :array_block_early_repayment_main="array_block_early_repayment_main"
                    :max_date="max_date"
                    :loan_term="loan_term"
                    :min_date_holidays="min_date_holidays"
                    :array_selected_dates="array_selected_dates"
                    :answers="answers"
                    :time_data_loan="time_data_loan"
                    @sendEearlyRepaymentPeriod="receivedEearlyRepaymentPeriod"
                    @sendEearlyRepaymentPeriodBegin="receivedEearlyRepaymentPeriodBegin"
                    @sendBeginToMain="receivedEearlyRepaymentPeriodBegin"
                    @sendClearBeginCalendar = "receivedClearBeginCalendar"

                  )

                template
                  component-calendar-period-end(
                    :ref="`js-calendar-early-period-end-${item.id}`"
                    :class_calendar="`js-calendar-early-period-end-${item.id}`"
                    :blockId="item.id"
                    :min_date_holidays_end="min_date_holidays_end"
                    :array_block_early_repayment_end="array_block_early_repayment_end"
                    :max_date="max_date"
                    :loan_term="loan_term"
                    :array_selected_dates="array_selected_dates"
                    :answers="answers"
                    :time_data_loan="time_data_loan"
                    @sendEearlyRepaymentEnd="receivedEearlyRepaymentEnd"
                  )




            .mor-rep-calculators__wrapper-match-warning.margin.display-none.js--wrapper-match-warning()
              .mor-rep-calculators__match-warning-wr-icon
                .mor-rep-calculators__match-warning-icon
              .calc-tax-deduc-new__block-subtitle.mor-rep-calculators__match-warning-des
                p Досрочное пополение во время ипотечных каникул прекращает их действие. Измените дату платежа или параметры каникул
            .calc-tax-deduc-new__row.js--tax-deduc-row
              .calc-tax-deduc-new__container-block.mor-rep-calculators__parent-tooltip-mobile.js--tooltip-parent
                  .calc-tax-deduc-new__row-title-container.mor-rep-calculators__row-title-switch
                    p.calc-tax-deduc-new__row-title Что хотите уменьшить?
                    span.content-note.desctop.content-note__center.js--content-note(v-if="tooltip_early['early-what-reduce']!==''")
                      span.content-note__text {{tooltip_early["early-what-reduce"]}}
                    span.content-note.mobile(
                      v-if="tooltip_early['early-what-reduce']!==''"
                      @click="openTooltipMobile"
                    )
                  div(v-if="tooltip_early['early-what-reduce']!==''")
                    .select__background.modal-special-background(@click="closeTooltipMobile")
                    .select-list__selection-window.modal-special-styles.js--openlist-body
                      .select-list__head
                        p Что хотите уменьшить
                        .select-list__head-close(@click="closeTooltipMobile")
                          svg(width='10', height='10', viewbox='0 0 10 10', fill='none', xmlns='http://www.w3.org/2000/svg')
                            path(fill-rule='evenodd', clip-rule='evenodd', d='M0.209209 0.209209C0.488155 -0.0697365 0.940416 -0.0697365 1.21936 0.209209L5 3.98985L8.78064 0.209209C9.05958 -0.0697365 9.51184 -0.0697365 9.79079 0.209209C10.0697 0.488155 10.0697 0.940416 9.79079 1.21936L6.01015 5L9.79079 8.78064C10.0697 9.05958 10.0697 9.51184 9.79079 9.79079C9.51184 10.0697 9.05958 10.0697 8.78064 9.79079L5 6.01015L1.21936 9.79079C0.940416 10.0697 0.488155 10.0697 0.209209 9.79079C-0.0697365 9.51184 -0.0697365 9.05958 0.209209 8.78064L3.98985 5L0.209209 1.21936C-0.0697365 0.940416 -0.0697365 0.488155 0.209209 0.209209Z', fill='#252628')
                      .select-list__wr-search.mor-rep-calculators__wr-search
                        p {{tooltip_early["early-what-reduce"]}}
                  .radio-button-switch.mor-rep-calculators__radio-button-switch.js--for-clear-field.js--for-clear-radio-what-reduce
                    .radio-button-switch__item
                      input.js--radio-what-reduce(
                        type="radio"
                        :name="`decrease-${item.id}`"
                        value="payment"
                        checked="checked"
                        :id="`radio_btn_payment-${item.id}`"
                        @change="whatReduce"
                      )
                      label(:for="`radio_btn_payment-${item.id}`") Платеж
                    .radio-button-switch__item
                      input.js--radio-what-reduce(
                        type="radio"
                        :name="`decrease-${item.id}`"
                        value="term"
                        :id="`radio_btn_term-${item.id}`"
                        @change="whatReduce"
                      )
                      label(:for="`radio_btn_term-${item.id}`") Срок

            .calc-tax-deduc-new__row.mor-rep-calculators__earlr-repayment-footer.js--tax-deduc-row
              .mor-rep-calculators__footer-early-repayment(
                :class="hasActiveFields(item)?'active':''"
              )
                button.btn_s.btn-icon-plus.transparent_black_border(
                  type="button"
                  @click="addBlock"
                  v-if="index==array_block_early_repayment.length-1&&array_block_early_repayment.length<19"
                ) Добавить досрочное погашение
                .mor-rep-calculators__footer-wrapper-col-right
                  //кнопка очистить
                  .mor-rep-calculators__clear-block(
                    @click="clearAllFieldBlock(item.id, $event)"
                    v-show="hasActiveFields(item)"
                  )
                    .mor-rep-calculators__clear-block-icon
                    p Очистить
                  button.btn_s.black.mor-rep-calculators__btn-result.js--mor-btn-result(
                    v-if="index==array_block_early_repayment.length-1"
                    :class="btn_status===false?'disabled':''"
                    type="button"
                    @click="totalCalculation"
                  ) Рассчитать
            .mor-rep-calculators__input-error.mor-rep-calculators__after-sand-error(v-show="description_after_sand!==null") {{description_after_sand}}
</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';
import componentCalendar from './v-2-component-calendar-early-repayment.vue';
import componentCalendarPeriodBegin from './v-2-component-calendar-period-begin.vue';
import componentCalendarPeriodEnd from './v-2-component-calendar-period-end.vue';
import componentButtonResult from './v-2-component-button-result.vue';
import VanillaCalendar from "../../vanilla-calendar";
import Vue from "vue";
export default {
  name: 'v-component-early-repayment',
  mixins: [numberFormatting],
  props:['answers','result_comparing_holidays_early','btn_status','tooltip_early', 'description_after_sand'],
  data(){
    const initialId = 0;
    return {
      count:1,

      block_index:null,
      min_date_holidays: `${new Date().getFullYear() - 30}-01-01`,
      min_date_holidays_begin: `${new Date().getFullYear() - 30}-01-01`,
      min_date_holidays_end: `${new Date().getFullYear() - 30}-01-01`,
      max_date: `${new Date().getFullYear() + 1}-12`,
      loan_term:0,//срок кредита
      term_holiday:0, //срок каникул
      data_holiday:null, //дата каникул

      class_calendar:['js-calendar-early-repayment-1','js-calendar-early-repayment'],

      nextId: initialId,
      array_periodicity: [
        {
          key:1,
          title:'Единовременно'
        },
        {
          key:2,
          title:'Раз в месяц'
        },
        {
          key:3,
          title:'Раз в год'
        },


      ],
      registration_date: {},


      array_block_early_repayment:[
        {
          id: initialId,
          field_data:'',
          field_amount:'',
          field_period:'',
          repetitionPeriod:'all-term',
          periodicityParameter:0,
          dateEarly:[''],
          whatReduce:'payment',
          fieldAmount:''
        }
      ],
      //начало периода досрочного погашения
      array_block_early_repayment_period:[
        {
          id: initialId,
          min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
          selected_value:null,
          flag:0
        }
      ],
      array_block_early_repayment_end:[
        {
          id: initialId,
          min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
          selected_value:null,
          selected_value_calculations:null,
          flag:0
        }
      ],
      array_block_early_repayment_main:[
        {
          id: initialId,
          min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
          selected_value:null,
          flag:0
        }
      ],
      array_block_early_repayment_all_period:[
        {
          id: initialId,
          selected_value_end:null,
          selected_value_begin:null,
        }
      ],


      radio_btn_payment:'payment',
      radio_btn_term:'term',
      //выбранный период плвторения
      selected_repetition_period:'all-term',
      //js класс для календаря начало периода
      class_calendar_begin:'js--calendar-begin',
      class_calendar_end:'js--calendar-end',

      // просто массив с названиями месяцев
      obj_month:["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"],
      array_early_repayment:[],
      array_early_repayment_temporary:[],



      select_period:0, //выбранный период (1 - единовременно, 2 -раз в месяц, 3 раз в год)
      select_period_array:[], //массив с выбранными периодами для различных блоков с досрочным погашением



      array_early_repayment_date:[], //дата досрочного погашение
      array_amount_early_repayment:[],//сумму досрочного погашения
      array_selected_dates:[], //выбранные даты
      array_what_reduce:[
        {
          index:initialId,
          what_reduce:'payment'
        }
      ],// что уменьшить
      time_data_loan:0,


      block_requared:[
        {
          id:initialId,
          required_first_block:[false,false,false],
          required_second_block:[false,false]
        }
      ]




    }
  },
  methods:{

    hasActiveFields(item) {

      return item.field_data!=='' || item.field_amount!=='' || item.field_period!==''
    },

    receivedClearHolidayReceive(index){
      //передаю в календарь периодов команду и флаг, что в основном календаре блока досрочного погашения стёрли дату
      this.min_date_holidays_begin = this.min_date_holidays
      this.min_date_holidays_end = this.min_date_holidays
      eventBus.$emit('sendDataBeginPeriod',[index,null])
      const existingItems = this.array_block_early_repayment.find(item => item.id === index);
      if (existingItems) {
        existingItems.field_data=''
      }
      this.$emit('sendButtonResult')

    },

    receivedClearBeginCalendar(index) {
      this.$emit('sendClearInCalendarBegin', index)
      eventBus.$emit('sendClearInCalendarBegin', index)
    },

    clearPeriodicity(e){
      e.stopPropagation();
      const element = e.currentTarget;
      const container_wr = element.closest('.js--acc-wr')
      const container = element.closest('.js--container-block-early')
      if (container) {
        const data = parseInt(container.getAttribute('data-index'))
        for (let i = this.select_period_array.length -1; i>=0;i--){
          if (this.select_period_array[i].key === data) {
            this.select_period_array.splice(i,1)
          }
        }
        container.querySelector('.js--repetition-period').classList.remove('active')
        container.querySelector('input[value="all-term"]').click()

        const existingItems = this.array_block_early_repayment.find(item => item.id === data);
        if (existingItems) {
          existingItems.field_period=''
        }
      }

      const parent = element.closest('.js--container-block-required');
      if (parent) {
        const block_input = parent.querySelector('.js--for-clear-field')
        //при клике очистить всё переключение в дефолтное состояние списка переодичность в блоке досрочное погашение
        if (block_input.classList.contains('js--for-clear-list-periodicity')) {
          if (block_input.querySelector('.js--select-option')) {
            block_input.querySelector('.js--select-option').classList.add('input-emty')
            block_input.querySelector('.js--select-option').textContent = 'Выберите параметр'
            if (block_input.querySelector('.js--select-option').classList.contains('js-early-required')) {
              block_input.querySelector('.js--select-option').classList.remove('js-filled')
              container_wr.classList.remove('period-full')
              block_input.querySelector('.js--select-option').classList.remove('btn-active')
            }
            if (block_input.querySelector('.js--openlist-item.active')) {
              block_input.querySelector('.js--openlist-item.active').classList.remove('active')
            }
          }
        }
      }
      element.classList.remove('active')
      this.$emit('sendButtonResult')

    },




    //очищаю поля
    clearInputEarlyRepayment(e){
      const element = e.currentTarget;
      const parent = element.closest('.js--tex-deduc-input');
      const container = element.closest('.js--acc-wr')
      const main_container = this.$el.closest('.js--block-grid-area');
      if (element.closest('.js--for-clear-field')
        && element.closest('.js--for-clear-field').querySelector('.js-early-required')) {
        element.closest('.js--for-clear-field').querySelector('.js-early-required').classList.remove('js-filled')
        element.closest('.js--for-clear-field').querySelector('.js-early-required').classList.remove('btn-active')
        container.classList.remove('sum-full')

        if (main_container) {
          main_container.classList.remove('amount-full')
        }
      }



      if (parent) {
        parent.querySelector('input').value='';
        parent.querySelector('input').classList.remove('active')
        element.classList.remove('active')

        const index = parseInt(element.closest('.js--container-block').getAttribute('data-index'))

        const itemIndex = this.array_amount_early_repayment.findIndex(item => item.index === index);

        if (itemIndex !==-1) {
          // this.array_amount_early_repayment.splice(itemIndex, 1)
          this.array_amount_early_repayment[itemIndex].amount = 0


        }

        const existingItems = this.array_block_early_repayment.find(item => item.id === index);
        if (existingItems) {
          existingItems.field_amount=''
        }
      }
      this.$emit('sendButtonResult')

    },

    //когда дата в досрочном погашении раньше даты оформления ипотеки
    receivedEearlyRepaymentClear(blockId){
      setTimeout(()=>{
        this.clearAllFieldBlock(blockId)
      },100)
    },

    //очистить все поля блока
    clearAllFieldBlock(blockId,el) {

      const parent = document.querySelector(`.js--container-block[data-index="${blockId}"]`);
      const container = parent.querySelector('.js--acc-wr')
      const targetKey = parseInt(parent.dataset.index)
      container.classList.remove('calendar-full')
      container.classList.remove('sum-full')
      container.classList.remove('period-full')
      const main_container = this.$el.closest('.js--block-grid-area');
      if (main_container) {
        main_container.classList.remove('amount-full')
      }

      if (this.array_block_early_repayment.length===1) {
        if (parent) {
          const array_block_input = parent.querySelectorAll('.js--for-clear-field')
          for (let item of array_block_input) {
            if (item.querySelector('input.js--normal-field')) {
              item.querySelector('input.js--normal-field').value = ''
            }
            //при клике очистить всё переключение в дефолтное состояние списка переодичность в блоке досрочное погашение
            if (item.classList.contains('js--for-clear-list-periodicity')) {
              if (item.querySelector('.js--select-option')) {
                item.querySelector('.js--select-option').classList.add('input-emty')
                item.querySelector('.js--select-option').textContent='Выберите параметр'
                if (item.querySelector('.js--openlist-item.active')) {
                  item.querySelector('.js--openlist-item.active').classList.remove('active')
                }
              }
            }
            parent.querySelector('.js--repetition-period input[value="all-term"]').click()
            //при клике очистить всё переключение в дефолтное состояние радиокнопки группы что хотите уменьшить в блоке досрочное погашение
            if (item.classList.contains('js--for-clear-radio-what-reduce')) {
              if(item.querySelector('input[type="radio"]').value==='payment') {
                item.querySelector('input[type="radio"]').click();
              }
            }
            //при клике очистить всё очищение поля инпут календаря
            if (item.querySelector('input.js--calendar-field')) {
              item.querySelector('input.js--calendar-field').value = ''
            }
            if (item.querySelector('.js--clear-calc-tax')) {
              item.querySelector('.js--clear-calc-tax').classList.remove('active')
            }
            if (item.closest('.js--container-block-required') && item.closest('.js--container-block-required').querySelector('.js--required-error')) {
              item.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
            }
            item.classList.remove('input_error')
          }
          if (parent.querySelector('.js--repetition-period')) {
            parent.querySelector('.js--repetition-period').classList.remove('active')
          }
          const array_requared = parent.querySelectorAll('.js-early-required')
          for (let item of array_requared) {
            item.classList.remove('js-filled')
            item.classList.remove('btn-active')
          }

          const targetComponentUpdate = this.$children.find(c => c.calendarContainerId === `calendar-${blockId}`)
          if (targetComponentUpdate) {
            targetComponentUpdate.updateCalendar()
          }

          const targetComponentUpdateEnd = this.$children.find(c => c.calendarContainerId === `calendar-end-${blockId}`)
          if (targetComponentUpdateEnd) {
            targetComponentUpdateEnd.updateCalendar()
          }


        }
      }

      if (this.array_block_early_repayment.length>1){
        if (parent) {
          const targetComponent = this.$children.find(c => c.calendarContainerId === `calendar-${blockId}`)
          if (targetComponent) {
            targetComponent.destroyCalendar()
          }
          const targetComponentBegin = this.$children.find(c => c.calendarContainerId === `calendar-begin-${blockId}`)
          if (targetComponentBegin) {
            targetComponentBegin.destroyCalendar()
          }

          const targetComponentEnd = this.$children.find(c => c.calendarContainerId === `calendar-end-${blockId}`)
            if (targetComponentEnd) {
              targetComponentEnd.destroyCalendar()
            }


        }
      }
      if (parent) {
        // eventBus.$emit('sendDataBeginPeriod',[blockId,null])




        //отправляю в календарь блока
        // eventBus.$emit('emitClearCalendarAll')

        //отправил в календарь, что его стёрли
        // eventBus.$emit('sendDataDesnroyCalendar')


        // this.min_date_holidays_begin = this.min_date_holidays
        // this.min_date_holidays_end = this.min_date_holidays
        //



        if (this.array_block_early_repayment.length > 1) {
          const index = this.array_block_early_repayment.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.array_block_early_repayment.splice(index, 1);
          }
        }
        else if (this.array_block_early_repayment.length === 1) {
          const obj = this.array_block_early_repayment[0];
          if (obj.id === blockId) {
            this.array_block_early_repayment[0].field_data = ''
            this.array_block_early_repayment[0].field_amount = ''
            this.array_block_early_repayment[0].field_period = ''

            this.array_block_early_repayment[0].repetitionPeriod='all-term'
            this.array_block_early_repayment[0].periodicityParameter=0
            this.array_block_early_repayment[0].dateEarly=['']
            this.array_block_early_repayment[0].whatReduce='payment'
            this.array_block_early_repayment[0].fieldAmount=''
          }
        }
        // console.log('this.array_block_early_repayment перед');
        // console.log(this.array_block_early_repayment);

        //this.array_early_repayment
        for (let i = this.array_early_repayment.length-1; i>=0;i--){
          if (this.array_early_repayment[i].id ===blockId) {
            this.array_early_repayment.splice(i,1)
          }
        }
        // console.log('this.array_early_repayment');
        // console.log(this.array_early_repayment);

        //---------------------------------------------------------------------

        // this.array_amount_early_repayment
        for (let i = this.array_amount_early_repayment.length-1; i>=0;i--){
          if (this.array_amount_early_repayment[i].index ===blockId) {
            this.array_amount_early_repayment.splice(i,1)
          }
        }

        // console.log('this.array_amount_early_repayment');
        // console.log(this.array_amount_early_repayment);

        //---------------------------------------------------------------------

        //this.array_what_reduce
        if (this.array_what_reduce.length > 1) {
          const index = this.array_what_reduce.findIndex(obj => obj.index === blockId);
          if (index !== -1) {
            this.array_what_reduce.splice(index, 1);
          }
        } else if (this.array_what_reduce === 1) {
          const obj = this.array_what_reduce[0];
          if (obj.index === blockId) {
            this.array_what_reduce[0].what_reduce = 'payment'
          }
        }
        // console.log('После this.array_what_reduce');
        // console.log(this.array_what_reduce);


        if (this.block_requared.length > 1) {
          const index = this.block_requared.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.block_requared.splice(index, 1);
          }
        } else if (this.block_requared === 1) {
          const obj = this.block_requared[0];
          if (obj.id === blockId) {
            this.block_requared[0].required_first_block=[false,false,false]
            this.block_requared[0].required_second_block=[false,false]
          }
        }


        //---------------------------------------------------------------------

        //this.array_block_early_repayment_period
        if (this.array_block_early_repayment_period.length > 1) {
          const index = this.array_block_early_repayment_period.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.array_block_early_repayment_period.splice(index, 1);
          }
        } else if (this.array_block_early_repayment_period === 1) {
          const obj = this.array_block_early_repayment_period[0];
          if (obj.id === blockId) {
            if (this.min_date_holidays_begin === '1995-01-01') {
              this.array_block_early_repayment_period[0].min_date_holidays_begin = `${new Date().getFullYear() - 30}-01-01`
              this.array_block_early_repayment_period[0].selected_value = null
              this.array_block_early_repayment_period[0].flag = 0
            } else {
              this.array_block_early_repayment_period[0].min_date_holidays_begin = this.min_date_holidays_begin
              this.array_block_early_repayment_period[0].selected_value = null
              this.array_block_early_repayment_period[0].flag = 0
            }
          }
        }
        // console.log('После this.array_block_early_repayment_period');
        // console.log(this.array_block_early_repayment_period);

        //---------------------------------------------------------------------

        //this.array_block_early_repayment_main
        if (this.array_block_early_repayment_main.length > 1) {
          const index = this.array_block_early_repayment_main.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.array_block_early_repayment_main.splice(index, 1);
          }
        } else if (this.array_block_early_repayment_main === 1) {
          const obj = this.array_block_early_repayment_main[0];
          if (obj.id === blockId) {
            if (this.min_date_holidays_begin === '1995-01-01') {
              this.array_block_early_repayment_main[0].min_date_holidays_begin = `${new Date().getFullYear() - 30}-01-01`
              this.array_block_early_repayment_main[0].selected_value = null
              this.array_block_early_repayment_main[0].flag = 0
            } else {
              this.array_block_early_repayment_main[0].min_date_holidays_begin = this.min_date_holidays_begin
              this.array_block_early_repayment_main[0].selected_value = null
              this.array_block_early_repayment_main[0].flag = 0
            }
          }
        }
        // console.log('this.array_block_early_repayment_main');
        // console.log(this.array_block_early_repayment_main);

        //---------------------------------------------------------------------

        //this.array_block_early_repayment_all_period
        if (this.array_block_early_repayment_all_period.length > 1) {
          const index = this.array_block_early_repayment_all_period.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.array_block_early_repayment_all_period.splice(index, 1);
          }
        } else if (this.array_block_early_repayment_all_period === 1) {
          const obj = this.array_block_early_repayment_all_period[0];
          if (obj.id === blockId) {
            if (this.min_date_holidays_begin === '1995-01-01') {
              this.array_block_early_repayment_all_period[0].selected_value_end = null
              this.array_block_early_repayment_all_period[0].selected_value_begin = null
            } else {
              this.array_block_early_repayment_all_period[0].selected_value_end = null
              this.array_block_early_repayment_all_period[0].selected_value_begin = null
            }
          }
        }
        // console.log('после this.array_block_early_repayment_all_period');
        // console.log(this.array_block_early_repayment_all_period);

        //---------------------------------------------------------------------

        //this.array_block_early_repayment_end

        if (this.array_block_early_repayment_end.length > 1) {
          const index = this.array_block_early_repayment_end.findIndex(obj => obj.id === blockId);
          if (index !== -1) {
            this.array_block_early_repayment_end.splice(index, 1);
          }
        } else if (this.array_block_early_repayment_end === 1) {
          const obj = this.array_block_early_repayment_end[0];
          if (obj.id === blockId) {
            if (this.min_date_holidays_begin === '1995-01-01') {
              this.array_block_early_repayment_end[0].min_date_holidays_begin = `${new Date().getFullYear() - 30}-01-01`
              this.array_block_early_repayment_end[0].selected_value = null
              this.array_block_early_repayment_end[0].flag = 0
            } else {
              this.array_block_early_repayment_end[0].min_date_holidays_begin = this.min_date_holidays_begin
              this.array_block_early_repayment_end[0].selected_value = null
              this.array_block_early_repayment_end[0].flag = 0
            }
          }
        }
        // console.log('после this.array_block_early_repayment_end');
        // console.log(this.array_block_early_repayment_end);


        //---------------------------------------------------------------------

        //this.select_period_array
        for (let i = this.select_period_array.length-1; i>=0;i--){
          if (this.select_period_array[i].key ===blockId) {
            this.select_period_array.splice(i,1)
          }
        }
        // console.log('this.select_period_array');
        // console.log(this.select_period_array);

        //this.array_early_repayment_date
        for (let i = this.array_early_repayment_date.length-1; i>=0;i--){
          if (this.array_early_repayment_date[i][1] ===blockId) {
            this.array_early_repayment_date.splice(i,1)
          }
        }
        // console.log('this.array_early_repayment_date');
        // console.log(this.array_early_repayment_date);

      }

      // this.nextId = Math.max(...this.answers[2].map(obj => parseInt(obj.id)))

      this.term_holiday=0
      this.data_holiday=null
      this.$emit('sendButtonResult')
    },

    //--------------------------------------------------------------------------------------------------------

    // общая функция для методов при вводе в поле сумма кредита
    multiplyActionsInpuLoanAmount(perem,el) {
      this.numberFormattingThousandths(perem,el)
      //сумма досрочного погашения
      this.amountEarlyRepayment(el)
    },

    //добавляю блок с досрочным погашением
    addBlock(el) {

      const element = el.currentTarget;
      const data = parseInt(element.closest('.js--container-block').getAttribute('data-index'))

      if (this.array_block_early_repayment.length<=19){
        this.nextId++
        let obj = {
          index:data+1,
          field_data:false,
          field_amount:false,
          field_period:false
        }
        this.array_what_reduce.push({
          index:this.nextId,
          what_reduce:'payment'
        })
        this.array_block_early_repayment.push(
          {
            id: this.nextId,
            field_data: '',
            field_amount: '',
            field_period: '',
            repetitionPeriod:'all-term',
            periodicityParameter:0,
            dateEarly:[''],
            whatReduce:'payment',
            fieldAmount:''
          }
        );



        this.block_requared.push(
          {
            id: this.nextId,
            required_first_block:[false,false,false],
            required_second_block:[false,false]
          }
        )


        if(this.min_date_holidays_begin=='1995-01-01'){
          this.array_block_early_repayment_period.push({
            id: this.nextId,
            min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
            selected_value:null,
            flag:0
          })
          this.array_block_early_repayment_main.push({
            id: this.nextId,
            min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
            selected_value:null,
            flag:0
          })

          this.array_block_early_repayment_end.push({
            id: this.nextId,
            min_date_holidays_begin:`${new Date().getFullYear() - 30}-01-01`,
            selected_value:null,
            selected_value_calculations:null,
            flag:0
          })
          this.array_block_early_repayment_all_period.push({
            id: this.nextId,
            selected_value_end:null,
            selected_value_begin:null,
          })


        }
        else {

          this.array_block_early_repayment_period.push({
            id: this.nextId,
            min_date_holidays_begin:this.min_date_holidays_begin,
            selected_value:null,
            flag:0
          })
          this.array_block_early_repayment_main.push({
            id: this.nextId,
            min_date_holidays_begin:this.min_date_holidays_begin,
            selected_value:null,
            flag:0
          })
          this.array_block_early_repayment_end.push({
            id: this.nextId,
            min_date_holidays_begin:this.min_date_holidays_begin,
            selected_value:null,
            selected_value_calculations:null,
            flag:0
          })
          this.array_block_early_repayment_all_period.push({
            id: this.nextId,
            selected_value_end:null,
            selected_value_begin:null
          })


        }
      }
      // console.log(this.array_block_early_repayment.length);

    },
    generateId(){
      return Date.now

    },

    //записываю в переменный период повторения (На весь срок кредита или Выбрать период), чтобы показывать или нет блоки с календарём, если выбран "выбрать период"
    selectRepetitionPeriod(el){
      const element = el.currentTarget
      this.selected_repetition_period = element.getAttribute('value')

      const data = element.getAttribute('value')

      if (data==='choose-term') {
        const parent = element.closest('.js--container-block')
        const parentIndex = parseInt(parent.dataset.index)
        const existingItem = this.select_period_array.find(el => el.key === parentIndex)
        if (existingItem) {
          existingItem.period = 'choose-term'
        }

        const existingItemsPeriod = this.array_block_early_repayment.find(item => item.id === parentIndex);
        if (existingItemsPeriod) {
          existingItemsPeriod.repetitionPeriod ='choose-term'
        }
        element.closest('.js--container-repeat-mor').querySelector('.js--period-calendar').classList.remove('not-show')
      }
      else if (data==='all-term') {
        const parent = element.closest('.js--container-block')
        const parentIndex = parseInt(parent.dataset.index)
        const existingItem = this.select_period_array.find(el => el.key === parentIndex)
        if (existingItem) {
          existingItem.period = 'all-term'
        }

        const existingItemsPeriod = this.array_block_early_repayment.find(item => item.id === parentIndex);
        if (existingItemsPeriod) {
          existingItemsPeriod.repetitionPeriod ='all-term'
        }
        element.closest('.js--container-repeat-mor').querySelector('.js--period-calendar').classList.add('not-show')
      }

      //--------------------------------------------------------

        // const parent = element.closest('.js--container-block')
        // const parentIndex = parseInt(parent.dataset.index)
        // const existingItem = this.array_block_early_repayment.find(el => el.key === parentIndex)
        // if (existingItem) {
        //   existingItem.repetitionPeriod = data
        // }


      // else if (data==='all-term') {
      //   const parent = element.closest('.js--container-block')
      //   const parentIndex = parseInt(parent.dataset.index)
      //   const existingItem = this.array_block_early_repayment.find(el => el.key === parentIndex)
      //   if (existingItem) {
      //     existingItem.repetitionPeriod = 'all-term'
      //   }
      //   element.closest('.js--container-repeat-mor').querySelector('.js--period-calendar').classList.add('not-show')
      // }





      // else {
      //   this.select_period_array.push({
      //     key: parentIndex,
      //     value:selectedValue
      //   })
      // }


    },

    addOrReplace(mainArray,newItem) {
      const key = newItem[1];
      const index = mainArray.findIndex(item => item[1] === key);
      if (index!==-1) {
        return [
          ...mainArray.slice(0, index),
          newItem,
          ...mainArray.slice(index + 1)
        ];
      } else {
        return [...mainArray,newItem];
      }

    },




    //записываю в массив конец периода, потом буду его добавлять в основной массив
    receivedEearlyRepaymentEnd(array_data){

      const fountIdEnd = this.array_block_early_repayment_all_period.find(user => user.id === array_data[1])
      if (fountIdEnd && this.array_block_early_repayment_all_period[array_data[1]]!==undefined){
        this.array_block_early_repayment_all_period[array_data[1]].selected_value_end=array_data[0]
      }
      if (this.array_block_early_repayment_all_period[array_data[1]]!==undefined&&this.array_block_early_repayment_all_period[array_data[1]].selected_value_begin!==null) {
        this.array_early_repayment_date = this.addOrReplace(this.array_early_repayment_date,[this.array_block_early_repayment_all_period[array_data[1]].selected_value_begin, array_data[1]])
      }
    },


    //записываю данные календаря "Дата досрочного погашения" в массив, так как досрочек может быть много
    receivedEearlyRepayment(array_data) {


      this.array_early_repayment_date = this.addOrReplace(this.array_early_repayment_date,array_data)
      this.array_selected_dates.push(array_data[0])



      //передаю в календарь периодов просто команду, что в основном календаре блока досрочного погашения изменилась дата
      eventBus.$emit('sendDataBeginPeriod',[array_data[1],array_data[0],array_data[2]])
      // eventBus.$emit('sendDataEarlyCalendar',[array_data[1],array_data[0]])


      const fountId = this.array_block_early_repayment_period.find(user => user.id === array_data[1])
      if (fountId){
        // this.array_block_early_repayment_period[array_data[1]].min_date_holidays_begin=`${array_data[0][1]}-${array_data[0][0]}`
        fountId.selected_value=`${array_data[0][1]}-${array_data[0][0]}`
        fountId.flag=1

      }

      const fountIdAllPeriod = this.array_block_early_repayment_end.find(user => user.id === array_data[1])
      if (fountIdAllPeriod){
        fountIdAllPeriod.selected_value=`${array_data[0][1]}-${array_data[0][0]}`
        fountIdAllPeriod.selected_value_begin=array_data[0]
      }

      const existingItems = this.array_block_early_repayment.find(item => item.id === array_data[1]);
      if (existingItems) {
        existingItems.field_data=array_data[0][1]
        existingItems.dateEarly=array_data[0]
      }



    },



    //а это то что приходит с календаря периодов начало периода
    // записываю данные календаря "Дата досрочного погашения" в массив, так как досрочек может быть много
    receivedEearlyRepaymentPeriod(array_data) {

      this.array_early_repayment_date = this.addOrReplace(this.array_early_repayment_date,array_data)
      this.array_selected_dates.push(array_data[0])


      //передаю в основной календарь досрочки команду, что в  календаре начала периода  изменилась дата
      // eventBus.$emit('sendDataEarlyCalendar',[1,`${array_data[0][1]}-${array_data[0][0]}`])

    },

    //получаю и передаю в основной календарь досрочки команду, что в  календаре начала периода  изменилась дата
    receivedEearlyRepaymentPeriodBegin(array_data) {
      const t = `${array_data[0][1]}-${array_data[0][0]}`
      this.min_date_holidays_end = `${array_data[0][1]}-${array_data[0][0]}`

      //передаю в основной календарь досрочки команду, что в  календаре начала периода  изменилась дата
      eventBus.$emit('sendDataEarlyCalendar',[array_data[1],array_data[0]])

      const fountId = this.array_block_early_repayment_main.find(user => user.id === array_data[1])
      if (fountId){
        // this.array_block_early_repayment_main[array_data[1]].min_date_holidays_begin=`${array_data[0][1]}-${array_data[0][0]}`
        fountId.selected_value=`${array_data[0][1]}-${array_data[0][0]}`
        fountId.flag=1
      }


      const fountIdEnd = this.array_block_early_repayment_end.find(user => user.id === array_data[1])
      if (fountIdEnd){
        // this.array_block_early_repayment_end[array_data[1]].min_date_holidays_begin=`${array_data[0][1]}-${array_data[0][0]}`
        fountIdEnd.selected_value=`${array_data[0][1]}-${array_data[0][0]}`
        fountIdEnd.flag=1
      }
      const fountIdAllPeriod = this.array_block_early_repayment_end.find(user => user.id === array_data[1])
      if (fountIdAllPeriod){
        fountIdAllPeriod.selected_value=`${array_data[0][1]}-${array_data[0][0]}`
        if (this.array_block_early_repayment_all_period[array_data[1]]!==undefined) {
          this.array_block_early_repayment_all_period[array_data[1]].selected_value_begin=array_data[0]
        }

      }

      const fountIdAllPeriodU = this.array_block_early_repayment_all_period.find(user => user.id === array_data[1])
      if (fountIdAllPeriodU){
        fountIdAllPeriodU.selected_value_begin=array_data[0]
      }


      if (this.array_block_early_repayment_all_period[array_data[1]]!==undefined&&this.array_block_early_repayment_all_period[array_data[1]].selected_value_end!==null) {
        this.array_early_repayment_date = this.addOrReplace(this.array_early_repayment_date,array_data)
        this.array_selected_dates.push(array_data[0])
      }

    },


    //записываю в переменную выбранную переодичность, чтобы показывать или нет блок  Период повторения(раз в месяц - раз в год показывает)
    selectPeriod(el) {
      const element = el.currentTarget
      const container = element.closest('.js--acc-wr')
      this.select_period = parseInt(element.getAttribute('data-key'))
      const parent = element.closest('.js--container-block')
      const parentIndex = parseInt(parent.dataset.index)
      const selectedValue = parseInt(element.dataset.key)
      const main_container = this.$el.closest('.js--block-grid-area');



      if ((selectedValue===2 || selectedValue===3) && (element.closest('.js--container-repeat-mor') && element.closest('.js--container-repeat-mor').querySelector('.js--repetition-period'))) {
        element.closest('.js--container-repeat-mor').querySelector('.js--repetition-period').classList.add('active')
      } else {
        element.closest('.js--container-repeat-mor').querySelector('.js--repetition-period').classList.remove('active')
      }
      if (selectedValue===1) {
        parent.querySelector('input[value="all-term"]').click()
      }
      const existingItem = this.select_period_array.find(el => el.key === parentIndex)
      if (existingItem) {
        existingItem.value = selectedValue
      } else {
        this.select_period_array.push({
          key: parentIndex,
          value:selectedValue,
          period: 'all-term'
        })
      }

      const existingItems = this.array_block_early_repayment.find(item => item.id === parentIndex);
      if (existingItems) {
        existingItems.field_period=true
        existingItems.periodicityParameter=selectedValue
      }
      const wrapper = element.closest('.js--select')
      if (wrapper && wrapper.querySelector('.js--clear-calc-tax')) {
        wrapper.querySelector('.js--clear-calc-tax').classList.add('active')
      }
      if (wrapper && wrapper.querySelector('.js-early-required')) {
        wrapper.querySelector('.js-early-required').classList.add('js-filled')
        wrapper.querySelector('.js-early-required').classList.add('btn-active')
        container.classList.add('period-full')
      }
      if (main_container) {
        main_container.classList.add('period-full')
      }


      if (wrapper && wrapper.closest('.js--container-block-required')
        && wrapper.closest('.js--container-block-required').querySelector('.js--required-error')) {
        wrapper.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
      }
      this.$emit('sendButtonResult')



    },
    whatReduce(el){

      const target = el.currentTarget
      const parent = target.closest('.js--container-block')
      const index = parseInt(target.closest('.js--container-block').getAttribute('data-index'))

      const rawValue = target.value;
      if (rawValue === '') {
        const itemIndex = this.array_what_reduce.findIndex(item => item.index === index);
        if (itemIndex >-1) this.array_what_reduce.splice(itemIndex, 1)
      } else {
        const what_reduce = rawValue

        const existingItem = this.array_what_reduce.find(item => item.index === index);

        if (existingItem) {
          existingItem.what_reduce = what_reduce;
        } else {
          this.array_what_reduce.push({index, what_reduce});
        }
      }

      const existingItemsWhatReduce = this.array_block_early_repayment.find(item => item.id === index);
      if (existingItemsWhatReduce) {
        existingItemsWhatReduce.whatReduce=target.value
      }


    },

    //сумма досрочного погашения
    amountEarlyRepayment(el){
      let target;
      if (el instanceof Event) {
        target = el.currentTarget;
      }
      else if(el instanceof HTMLElement ) {
        target = el;
      }
      const main_container = this.$el.closest('.js--block-grid-area');
      // const target = el.currentTarget
      const parent = target.closest('.js--container-block')
      const index = parseInt(target.closest('.js--container-block').getAttribute('data-index'))
      const container = target.closest('.js--acc-wr')
      if (target.value.length>0) {
        if (target.classList.contains('js-early-required')) {
          target.classList.add('js-filled')
          target.classList.add('btn-active')
          container.classList.add('sum-full')
        }
        if (target.closest('.js--container-block-required')
          && target.closest('.js--container-block-required').querySelector('.js--required-error')) {
          target.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
        }
        if (target.closest('.js--for-clear-field')) {
          target.closest('.js--for-clear-field').classList.remove('input_error')
        }


        const existingRequared = this.block_requared.find(item => item.id === index);
        if (existingRequared) {
          existingRequared.required_first_block[0] = true;
        }


        if (main_container) {
          main_container.classList.add('amount-full')
        }
      }
      else if (target.value.length===0) {
        target.classList.remove('js-filled')
        container.classList.remove('sum-full')
        if (main_container) {
          main_container.classList.remove('amount-full')
        }
        const existingRequared = this.block_requared.find(item => item.id === index);
        if (existingRequared) {
          existingRequared.required_first_block[0] = false;
        }

      }
      const rawValue = target.value;
      if (rawValue === '') {
        const itemIndex = this.array_amount_early_repayment.findIndex(item => item.index === index);
        if (itemIndex >-1) this.array_amount_early_repayment.splice(itemIndex, 1)
      } else {
        const amount = Number(rawValue.replace(/\s+/g, ''));
        const existingItem = this.array_amount_early_repayment.find(item => item.index === index);

        if (existingItem) {
          existingItem.amount = amount;
        } else {
          this.array_amount_early_repayment.push({index, amount});
        }
      }

      const existingItems = this.array_block_early_repayment.find(item => item.id === index);
      if (existingItems) {
        existingItems.field_amount=target.value
      }
      const existingItemsWhatReduce = this.array_block_early_repayment.find(item => item.id === index);
      if (existingItemsWhatReduce) {
        existingItemsWhatReduce.fieldAmount=target.value
      }

      this.$emit('sendButtonResult')
    },


    // фунция, которая  если выбрана переодичность один месяц добавляет досрочки во все оставшиеся месяцы начиная от даты
    // досрочного погашения до конца ипотеки
    generateMortgageShedule(initialArray, totalMonth) {

      const [firstPayment] = initialArray;
      if (!firstPayment) return [];

      let {month, year, nameMonth, type, amount, id} = firstPayment;
      const result = [];
      // const monthCount = totalMonth - month + 1;
      const monthCount = totalMonth;

      if (monthCount <= 0) return  result;

      for (let i = 0; i<monthCount; i++) {
        result.push({month, year, nameMonth, type, amount, id});
        month++;
        if (month > 12) {
          month = 1;
          year++
        }
      }
      return result

    },

    generatePeriodMonth(inputArray, initialArray){

      const {selected_value_begin,selected_value_end} = inputArray;
      if (selected_value_begin!==null&&selected_value_begin!==undefined&&selected_value_end!==null&&selected_value_end!==undefined) {
        const {nameMonth, type, amount,id} = initialArray[0];
        const [beginMonth, beginYear] = selected_value_begin;
        const [endMonth, endYear] = selected_value_end

        const beginTotal = beginYear * 12 + beginMonth
        const endTotal = endYear * 12 + endMonth;

        const difference = endTotal - beginTotal;

        if(difference <=0) return initialArray;

        const result =[...initialArray];
        let {month:currentMonth, year: currentYear} = result[result.length - 1];
        for (let i=0; i<difference;i++) {
          currentMonth += 1;
          if (currentMonth > 12) {
            currentMonth = 1;
            currentYear += 1;
          }
          result.push({month: currentMonth, year: currentYear, nameMonth:nameMonth, type:type, amount:amount, id:id});
        }
        return result;
      }


    },

    generatePeriodYear(dates,arr){
      const {selected_value_begin,selected_value_end} = dates;

      const [beginMonth, beginYear] = selected_value_begin;
      const [endMonth, endYear] = selected_value_end;

      const totalBeginMonths = beginMonth + beginYear * 12
      const totalEndMonths = endMonth + endYear * 12
      const diffMonths = totalEndMonths - totalBeginMonths;

      if (diffMonths < 12) {
        return [...arr];
      }

      const N = Math.floor(diffMonths / 12);
      const original = arr[0];

      if (!original) {
        return [...arr]
      }

      const newArray = [...arr];
      for (let i = 1; i<=N; i++) {
        newArray.push({...original,year:original.year + i})
      }
      return newArray;

    },

    // фунция, которая  если выбрана переодичность один месяц добавляет досрочки во все оставшиеся месяцы начиная от даты
    // досрочного погашения до конца ипотеки
    generateMortgageSheduleYear(dosrochkaArray, mortgageStart,mortgageTermMonths) {
      if (dosrochkaArray.length ===0) return [];

      const firstDosrochka = dosrochkaArray[0];
      const endDate = this.addMonths(mortgageStart.year, mortgageStart.month, mortgageTermMonths);
      const result = [];

      if(this.isDateValid(firstDosrochka, mortgageStart, endDate)) {
        let currentDate = {...firstDosrochka};

        while (this.isDateLessOrEqual(currentDate, endDate)) {
          result.push({...currentDate});
          currentDate = this.addMonths(currentDate.year, currentDate.month, 12,currentDate.amount,currentDate.nameMonth,currentDate.type)
        }
      }
      return result;
    },

    addMonths(year, month, monthsToAdd,amount,nameMonth,type) {
      const totalMonths = (year - 1) * 12 + (month - 1) +monthsToAdd;
      const newYear =  Math.floor(totalMonths / 12) + 1;
      const newMonth = (totalMonths % 12) +1;
      return {year: newYear, month: newMonth,amount:amount, nameMonth:nameMonth,type:type};
    },

    isDateLessOrEqual(a,b){
      return a.year < b.year || (a.year === b.year && a.month <= b.month)
    },
    isDateValid(date, start, end) {
      return this.isDateLessOrEqual(start, date) && this.isDateLessOrEqual(date, end)
    },





    //формирую массив досрочных погашений
    earlyRepaiment(){

      this.array_early_repayment_temporary=[]
      this.array_early_repayment=[]



      if (this.array_early_repayment_date.length>0) {

        for (let item=0; item<this.array_early_repayment_date.length;item++) {
          let obj = {
            id:null,
            month: null,
            year: null,
            nameMonth: null,
            type:'',
            amount: 0,
            periodicity:0
          }


          if(this.array_early_repayment_date[item]!==undefined && this.array_amount_early_repayment[item]!==undefined&&
            this.array_what_reduce[item]!==undefined&&this.select_period_array[item]!==undefined){
            if ((parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.array_amount_early_repayment[item].index)&&
              parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.array_what_reduce[item].index))&&
              parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.select_period_array[item].key)) {
              obj.month = parseInt(this.array_early_repayment_date[item][0][0]) + 1
              obj.year = parseInt(this.array_early_repayment_date[item][0][1])
              obj.nameMonth = this.obj_month[parseInt(this.array_early_repayment_date[item][0][0])]
            }
          }






          if (this.array_amount_early_repayment[item]!==undefined
            &&this.array_amount_early_repayment[item].amount!==undefined){
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.array_amount_early_repayment[item].index)) {
              obj.amount = this.array_amount_early_repayment[item].amount
              obj.id = this.array_amount_early_repayment[item].index
            }

          }
          if (this.array_what_reduce[item]!==undefined
            &&this.array_what_reduce[item].what_reduce!==undefined){
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.array_what_reduce[item].index)) {
              obj.type = this.array_what_reduce[item].what_reduce
            }

          }

          //вот это не нужно либо переделать, у нас selected_repetition_period не массив
          if (this.selected_repetition_period[item]!==undefined
            &&this.selected_repetition_period[item].value!==undefined){
            obj.periodicity = this.selected_repetition_period[item].value
          }

          if (this.select_period_array.length > 0 && this.select_period_array[item] !== undefined && (this.select_period_array[item].value === 0 || this.select_period_array[item].value === 1)) {
            if (parseInt(this.array_early_repayment_date[item][1]) === parseInt(this.select_period_array[item].key)) {
              this.array_early_repayment.push(obj);
            }
          }

          //тут ещё нужно дополнить не только, что выбрана переодичность "раз в месяц" но и то, что выбрано "На весь срок кредита"
          if (this.select_period_array.length>0&&this.select_period_array[item]!==undefined&&(this.select_period_array[item].value === 2 && this.select_period_array[item].period==='all-term')) {
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.select_period_array[item].key)) {
              this.array_early_repayment_temporary.push(obj)
              this.array_early_repayment_temporary = this.generateMortgageShedule(this.array_early_repayment_temporary, this.loan_term);
              if (this.array_early_repayment_temporary!==undefined) {
                this.array_early_repayment.push(...this.array_early_repayment_temporary)
                this.array_early_repayment_temporary = []
              }
            }
          }
          //тут ещё нужно дополнить не только, что выбрана переодичность "раз в месяц" но и то, что выбрано "На весь срок кредита"
          if (this.select_period_array.length>0&&this.select_period_array[item]!==undefined&&(this.select_period_array[item].value === 3  && this.select_period_array[item].period==='all-term')) {
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.select_period_array[item].key)) {
              this.array_early_repayment_temporary.push(obj)
              this.array_early_repayment_temporary = this.generateMortgageSheduleYear(this.array_early_repayment_temporary,this.registration_date, this.loan_term);
              if (this.array_early_repayment_temporary!==undefined) {
                this.array_early_repayment.push(...this.array_early_repayment_temporary)
                this.array_early_repayment_temporary = []
              }
            }
          }

          if (this.select_period_array.length>0&&this.select_period_array[item]!==undefined&&(this.select_period_array[item].value === 2  && this.select_period_array[item].period==='choose-term')) {
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.select_period_array[item].key)) {
              this.array_early_repayment_temporary.push(obj)
              this.array_early_repayment_temporary = this.generatePeriodMonth(this.array_block_early_repayment_all_period[item],this.array_early_repayment_temporary)
              if (this.array_early_repayment_temporary!==undefined) {
                this.array_early_repayment.push(...this.array_early_repayment_temporary)
                this.array_early_repayment_temporary = []
              }
            }
          }

          if (this.select_period_array.length>0&&this.select_period_array[item]!==undefined&&(this.select_period_array[item].value === 3  && this.select_period_array[item].period==='choose-term')) {
            if (parseInt(this.array_early_repayment_date[item][1]) ===parseInt(this.select_period_array[item].key)) {
              this.array_early_repayment_temporary.push(obj)
              this.array_early_repayment_temporary = this.generatePeriodYear(this.array_block_early_repayment_all_period[item],this.array_early_repayment_temporary)
              if (this.array_early_repayment_temporary!==undefined){
                this.array_early_repayment.push(...this.array_early_repayment_temporary)
                this.array_early_repayment_temporary=[]
              }
            }
          }
        }

      }


    },




    //РАСЧЁТ И ОТПРАВКА ДАННЫХ РОДТЕЛЬСКОМУ КОМПОНЕНТУ

    //отправяю команду на расчёт по нажатию на кнопку Рассчитать, которая находится в этом блоке
    //эта кнопка находится в этом компоненте, в мобилке она будет находиться в другом месте
    totalCalculation() {

      this.earlyRepaiment();

      //отправляю данные из компоненты досрочное погашение в родитель
      this.$emit('sendArrayEarlyRepayment',this.array_early_repayment)
      this.$emit('sendArrayEarlyRepaymentTotal',this.array_block_early_repayment)

      //---------------------------------------------------------------------------------------------------------

      //отправляю в компоненты и в родитель, что была нажата кнопка Рассчитать, кнопка находится в этой компоненте
      eventBus.$emit('sendtotalCalculation')
      this.$emit('sendtotalCalculation')
      this.$emit('sendtotalCalculationRepaymentEnd',this.array_block_early_repayment_end)
      this.$emit('sendtotalCalculationRepaymentMain',this.array_block_early_repayment_main)
      this.$emit('sendtotalCalculationRepaymentAllPeriod',this.array_block_early_repayment_all_period)
      this.$emit('sendtotalCalculationRepaymentPeriod',this.select_period_array)
      this.$emit('sendtotalCalculationRepaymentDate',this.array_early_repayment_date)
      this.$emit('sendtotalCalculationRepaymentAmount',this.array_amount_early_repayment)
      this.$emit('sendtotalCalculationRepaymentSelectedDates',this.array_selected_dates)
      this.$emit('sendtotalCalculationRepaymentWhatReduce',this.array_what_reduce)

      // console.log('едрить колотить this.array_block_early_repayment');
      // console.log(this.array_block_early_repayment);
      // console.log('едрить колотить this.array_block_early_repayment_period');
      // console.log(this.array_block_early_repayment_period);
      // console.log('едрить колотить this.array_block_early_repayment_end');
      // console.log(this.array_block_early_repayment_end);
      // console.log('this.array_block_early_repayment_main');
      // console.log(this.array_block_early_repayment_main);
      // console.log('this.array_block_early_repayment_all_period');
      // console.log(this.array_block_early_repayment_all_period);
      // console.log('this.select_period_array');
      // console.log(this.select_period_array);
      // console.log('this.array_early_repayment_date');
      // console.log(this.array_early_repayment_date);
      // console.log('this.array_amount_early_repayment');
      // console.log(this.array_amount_early_repayment);
      // console.log('Отпрвка this.array_selected_dates');
      // console.log(this.array_selected_dates);
      // console.log('this.array_what_reduce');
      // console.log(this.array_what_reduce);
      //
      // console.log('Итоговый this.array_early_repayment');
      // console.log(this.array_early_repayment);


      const celevoiIds = new Set(this.array_early_repayment.map(item => item.id))


      if (this.array_early_repayment.length!==0){
        this.array_block_early_repayment = this.array_block_early_repayment.filter(item => celevoiIds.has(item.id))
        this.array_what_reduce = this.array_what_reduce.filter(item => celevoiIds.has(item.index))
        this.array_block_early_repayment_period = this.array_block_early_repayment_period.filter(item => celevoiIds.has(item.id))
        this.array_block_early_repayment_main = this.array_block_early_repayment_main.filter(item => celevoiIds.has(item.id))
        this.array_block_early_repayment_all_period = this.array_block_early_repayment_all_period.filter(item => celevoiIds.has(item.id))
        this.array_block_early_repayment_end = this.array_block_early_repayment_end.filter(item => celevoiIds.has(item.id))
      }
      this.array_amount_early_repayment = this.array_amount_early_repayment.filter(item => celevoiIds.has(item.index))
      this.select_period_array = this.select_period_array.filter(item => celevoiIds.has(item.key))
      this.array_early_repayment_date = this.array_early_repayment_date.filter(item => celevoiIds.has(item[1]))



      // console.log('this.array_block_early_repayment'); //последний удалять нельзя
      // console.log(this.array_block_early_repayment);
      // console.log('this.array_amount_early_repayment');
      // console.log(this.array_amount_early_repayment);
      // console.log('this.array_what_reduce');
      // console.log(this.array_what_reduce);//последний удалять нельзя
      // console.log('this.array_block_early_repayment_period');
      // console.log(this.array_block_early_repayment_period);//последний удалять нельзя
      // console.log('this.array_block_early_repayment_main');
      // console.log(this.array_block_early_repayment_main);//последний удалять нельзя
      // console.log('this.array_block_early_repayment_all_period');
      // console.log(this.array_block_early_repayment_all_period);//последний удалять нельзя
      // console.log('this.array_block_early_repayment_end');
      // console.log(this.array_block_early_repayment_end);//последний удалять нельзя
      // console.log('this.select_period_array');
      // console.log(this.select_period_array);
      // console.log('this.array_early_repayment_date');
      // console.log(this.array_early_repayment_date);
      // console.log(this.nextId);

    },

    async constructionBlock(){
      if(this.answers.length>0&&this.answers[2]&&this.answers[2].length>0){
        for(let i=0;i<this.answers[2].length;i++) {
          this.$nextTick(()=>{
            const parent = this.$el
            if (parent) {
              const wrapper = parent.querySelector(`.js--container-block-early[data-index='${this.answers[2][i].id}']`)
              if (wrapper) {
                //Сумма досрочки
                wrapper.querySelector('.js--normal-field').value=this.answers[2][i].field_amount
                wrapper.querySelector('.js--normal-field').closest('.js--for-clear-field').querySelector('.js--clear-calc-tax').classList.add('active')
                this.amountEarlyRepayment(wrapper.querySelector('.js--normal-field'))
                //Переодичность
                wrapper.querySelector(`.js--select .js--openlist-item[data-key='${this.answers[2][i].periodicityParameter}']`).click()
                wrapper.querySelector(`.js--for-clear-radio-what-reduce input[value='${this.answers[2][i].whatReduce}']`).click()
                wrapper.querySelector(`.js--repetition-period input[value='${this.answers[2][i].repetitionPeriod}']`).click()
              }
            }
          })
        }
      }
    },
  },

  mounted(){

    if(this.answers.length>0&&this.answers[2]&&this.answers[2].length>0){
      this.array_block_early_repayment=[]
      this.array_block_early_repayment=this.answers[2]

      this.array_block_early_repayment_period=[]
      this.array_block_early_repayment_end=[]
      this.array_block_early_repayment_main=[]
      this.array_block_early_repayment_all_period=[]
      this.array_what_reduce=[]

      for (let i=0;i< this.answers[2].length;i++) {
        let obj_repayment_period = {
          id: this.answers[2][i].id,
          min_date_holidays_begin:this.min_date_holidays_begin,
          selected_value:this.answers[2][i].earlyMain.selected_value,
          flag:0
        }
        let obj_repayment_end = {
          id: this.answers[2][i].id,
          min_date_holidays_begin:this.min_date_holidays_begin,
          selected_value:this.answers[2][i].earlyMain.selected_value,
          selected_value_calculations:null,
          flag:0
        }
        let obj_repayment_main = {
          id: this.answers[2][i].id,
          min_date_holidays_begin:this.min_date_holidays_begin,
          selected_value:this.answers[2][i].earlyMain.selected_value,
          flag:0
        }
        let obj_repayment_all_period = this.answers[2][i].earlyAllPeriod
        let obj_repayment_select_period_array = this.answers[2][i].earlySelectPeriod
        let obj_repayment_early_repayment_date = this.answers[2][i].earlyDate
        let obj_repayment_amount_early_repayment = this.answers[2][i].earlyAmount
        let obj_repayment_selected_dates = this.answers[2][i].dateEarly
        let obj_repayment_what_reduce = this.answers[2][i].whatReduceArray




        this.array_block_early_repayment_period.push(obj_repayment_period)
        this.array_block_early_repayment_end.push(obj_repayment_end)
        this.array_block_early_repayment_main.push(obj_repayment_main)
        this.array_block_early_repayment_all_period.push(obj_repayment_all_period)
        this.select_period_array.push(obj_repayment_select_period_array)
        this.array_early_repayment_date.push(obj_repayment_early_repayment_date)
        this.array_amount_early_repayment.push(obj_repayment_amount_early_repayment)
        this.array_selected_dates.push(obj_repayment_selected_dates)
        this.array_what_reduce.push(obj_repayment_what_reduce)

      }
      this.constructionBlock();
    }



  },
  created(){
    eventBus.$on('emitTimeDataLoan', (data) => {
      this.time_data_loan=data
    })

    //получил от компоненты "данные об ипотеке" срок кредита
    eventBus.$on('emitMonthlyPayment', (data) => {
      this.loan_term=data
    })

    //получил от компоненты "данные об ипотеке" дату получения кредита в виде массива [1, '2025'] и передаю месяц и год в компонент
    // календарь для ипотечных каникул
    eventBus.$on('emitDateLoanReceipt', (data) => {

      this.min_date_holidays = `${data[1]}-${data[0]}`
      this.min_date_holidays_begin = `${data[1]}-${data[0]}`
      for (let item of this.array_block_early_repayment_period){
        // item.min_date_holidays_begin=`${data[1]}-${data[0]}`
        Vue.set(item,'min_date_holidays_begin',`${data[1]}-${data[0]}`)
        Vue.set(item,'flag',0)
      }
      for (let item of this.array_block_early_repayment_main){
        // item.min_date_holidays_begin=`${data[1]}-${data[0]}`
        Vue.set(item,'min_date_holidays_begin',`${data[1]}-${data[0]}`)
        Vue.set(item,'flag',0)
      }
      for (let item of this.array_block_early_repayment_end){
        // item.min_date_holidays_begin=`${data[1]}-${data[0]}`
        Vue.set(item,'min_date_holidays_begin',`${data[1]}-${data[0]}`)
        Vue.set(item,'flag',0)
      }


      this.min_date_holidays_end = `${data[1]}-${data[0]}`
      this.registration_date = {year:data[1],month:data[0]}
    })
    //получил от компоненты "данные об ипотеке" срок кредита
    eventBus.$on('emitMonthlyPayment', (data) => {
      this.loan_term=data
    })

    //поучил от данных об ипотеке о том, что поле с латой в нём очистили
    eventBus.$on('emitClearCalendarHolidaysPayment', () => {
      this.min_date_holidays = `${new Date().getFullYear() - 30}-01-01`
      this.min_date_holidays_begin = `${new Date().getFullYear() - 30}-01-01`
      this.min_date_holidays_end = `${new Date().getFullYear() - 30}-01-01`
    })

    //поучил от данных об ипотеке о том, что поле с латой в нём очистили
    eventBus.$on('emitClearCalendarHolidaysPaymentAll', () => {
      this.min_date_holidays = `${new Date().getFullYear() - 30}-01-01`
      this.min_date_holidays_begin = `${new Date().getFullYear() - 30}-01-01`
      this.min_date_holidays_end = `${new Date().getFullYear() - 30}-01-01`
      this.loan_term=0
    })

    eventBus.$on('emitClearAllError', () => {
      const parent = this.$el
      if (parent) {
        const array_block_input = parent.querySelectorAll('.js--for-clear-field')
        for (let item of array_block_input) {
          if (item.closest('.js--container-block-required') && item.closest('.js--container-block-required').querySelector('.js--required-error')) {
            item.closest('.js--container-block-required').querySelector('.js--required-error').classList.add('display-none')
          }
          item.classList.remove('input_error')
        }
      }
    })

    eventBus.$on('backToEarly', (data) => {
      // console.log(data);
    })




  },
  computed:{
    allFieldsFilled() {
      return (
        this.select_period !==0 &&
        this.field_loan_term_error !=='' &&
        this.loan_amount !==0 &&
        this.i_calculation !==0
      )
    }

  },
  watch:{
    result_comparing_holidays_early(){


      const blocks = document.querySelectorAll('.js--container-block-early');

      const ids = new Set(this.result_comparing_holidays_early.map(item => item.id))

      blocks.forEach(block => {
        const id = Number(block.dataset.index)
        if(ids.has(id)) {
          if (block.querySelector('.js--wrapper-match-warning')) {
            block.querySelector('.js--wrapper-match-warning').classList.remove('display-none')
          }
          if (block.querySelector('.js--wrapper-match-alarm')) {
            block.querySelector('.js--wrapper-match-alarm').classList.remove('display-none')
          }

          if (block.querySelector('.js--mor-rep-input-error')) {
            block.querySelector('.js--mor-rep-input-error').classList.remove('display-none')
          }


        }
        else{
          if (block.querySelector('.js--wrapper-match-warning')) {
            block.querySelector('.js--wrapper-match-warning').classList.add('display-none')
          }
          if (block.querySelector('.js--wrapper-match-alarm')) {
            block.querySelector('.js--wrapper-match-alarm').classList.add('display-none')
          }

          if (block.querySelector('.js--mor-rep-input-error')) {
            block.querySelector('.js--mor-rep-input-error').classList.add('display-none')
          }


        }
      })

    },
    array_block_early_repayment:{
      handler(){

      },
      deep: true
    }





  },

  components:{
    componentCalendar,
    componentCalendarPeriodBegin,
    componentCalendarPeriodEnd,
    componentButtonResult
  },


};
</script>
<style scoped>
</style>
