<template lang="pug">
  .sticky-aside.calc-tax-deduc-new__sticky-aside(ref="heightBlock")
    .calc-tax-deduc-new__block.mobile-padding.grey


</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
export default {
  name: 'v-component-repayment-data',
  data(){
    return {

    }
  },
  methods:{

  },
  mounted(){
  },
  computed:{

  },

  watch:{

  },
  components:{

  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
