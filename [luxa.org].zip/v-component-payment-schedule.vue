<template lang="pug">
  .calc-tax-deduc-new__block.grey.js--container-block
      .calc-tax-deduc-new__container-title
        h3.calc-tax-deduc-new__block-title.big Данные об ипотеке
      .mortgage-calculator__payment-table.refinancing-calc__payment-table
        table.iksweb
          thead
            tr
              td №
              td Месяц и год платежа
              td Задолженность
              td Погашение процентов
              td Погашение основного долга
              td Сумма платежа




</template>
<script>
import eventBus from '../development-tools/eventBus.vue';
import Storage from '../development-tools/state.vue';
import numberFormatting from '../mixin/numberFormatting.js';

export default {
  name: 'v-component-payment-schedule',
  mixins: [numberFormatting],
  data(){
    return {

    }
  },
  methods:{


  },
  mounted(){
  },
  computed:{

  },

  watch:{

  },
  components:{

  },
  updated() {

  },
  created(){
  //  Тут помещаюстя Шина событий
  }
};
</script>
<style scoped>
</style>
