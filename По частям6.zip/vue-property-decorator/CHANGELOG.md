Changelog

# v8.5.1

- Move `vue-class-component` to `dependencies`

# v8.5.0

- Revert #299
- Add CHANGELOG.md
- Fix README.md (#319)
- Move `vue-class-component` to `peerDependencies`
