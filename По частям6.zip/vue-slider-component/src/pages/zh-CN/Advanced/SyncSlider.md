# 同步多个滑块

<example :value="example1"></example>

::: example syncSlider :::
