# 可输入的滑块值

<example :value="example1"></example>

::: example input :::