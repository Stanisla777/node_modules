# 刻度标记

### 当 `marks` 为 `true`

<example :value="example1"></example>

### 当 `marks` 的类型为 `Object`

<example :value="example2"></example>

### 当 `marks` 的类型为 `Array`

<example :value="example3"></example>

### 当 `marks` 的类型为 `Function`

<example :value="example4"></example>

### 配合 `included` 使用

<example :value="example5"></example>

### 使用 `hideLabel` 隐藏 label

<example :value="example6"></example>

::: example marks :::