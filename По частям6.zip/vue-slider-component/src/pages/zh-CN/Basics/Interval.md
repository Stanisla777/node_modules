# 间隔

### 多段间隔

<example :value="example1"></example>

::: example interval :::