# The \<input> linkage

<example :value="example1"></example>

::: example input :::