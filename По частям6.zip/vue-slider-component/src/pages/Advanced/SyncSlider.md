# Sync of multi-component

<example :value="example1"></example>

::: example syncSlider :::
