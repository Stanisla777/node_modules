# Interval

### Multiple Step

<example :value="example1"></example>

::: example interval :::