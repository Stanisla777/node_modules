# Range mode

Parameters that are only valid in range mode

  - `enableCross`
  - `minRange`
  - `maxRange`
  - `fixed`

### Prohibit slider crossing

<example :value="example1"></example>

### Limit the distance between the sliders

<example :value="example2"></example>

::: example range :::