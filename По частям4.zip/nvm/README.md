# nvm

This is not the node version manager you are looking for.

Please visit http://nvm.sh for all your node version management needs.