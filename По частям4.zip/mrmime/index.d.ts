export const mimes: Record<string, string>;
export function lookup(extension: string): string | undefined;
