import 'rxjs-compat/add/operator/findIndex';
