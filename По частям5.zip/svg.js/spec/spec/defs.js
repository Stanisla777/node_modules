describe('Defs', function() {
  var defs

  beforeEach(function() {
    defs = draw.defs()
  })

  it('creates an instance of SVG.Defs', function() {
    expect(defs instanceof SVG.Defs).toBeTruthy()
  })

})