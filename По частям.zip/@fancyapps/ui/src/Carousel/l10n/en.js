export default {
  NEXT: "Next slide",
  PREV: "Previous slide",
  GOTO: "Go to slide #%d",
};
