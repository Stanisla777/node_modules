export default {
  NEXT: "Volgende dia",
  PREV: "Vorige dia",
  GOTO: "Ga naar dia #%d",
};
